Ibra.V.O — تطبيق Electron

نسخة بسيطة تحوي واجهة الـ web app داخل نافذة Electron.

ملفات مهمة:
- index.html — نسخة من واجهة `ibra_v_o_studio_max_pro.html`.
- main.js — مدخل تطبيق Electron.
- preload.js — جسر آمن لواجهة الويب (contextBridge).
- package.json — سكربتات التشغيل والحزم.

تشغيل محلي (Windows PowerShell):
```powershell
cd "c:\Users\HP\Documents\ibra-electron"
npm install
npm start
```

نصائح:
- التطبيق يستخدم مكتبات عبر CDN (إنترنت مطلوب أثناء التشغيل).
- ضع مفتاح Gemini API داخل التطبيق عبر زر "إعداد مفتاح الذكاء الاصطناعي".
- لتجهيز ملف تنفيذي استخدم: `npm run pack` (يتطلب electron-packager).
