// Preload script to expose a safe bridge if needed in future
const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  platform: process.platform
});